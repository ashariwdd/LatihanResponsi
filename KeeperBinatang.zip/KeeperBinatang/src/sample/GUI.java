package sample;

import java.awt.event.*;
import java.io.*;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;
import javax.xml.crypto.Data;

public class GUI extends JFrame implements ActionListener {
    String Idkeeper,Nama,Alamat,JenisKelamin,Jabatan,Notelp;
    JScrollPane scroll;
    JRadioButton rd_laki, rd_perempuan;
    JComboBox jc_jabatan;
    Statement statement;

    JButton cari = new JButton();
    JLabel idkeeper = new JLabel();
    JLabel nama = new JLabel();
    JLabel alamat = new JLabel();
    JLabel jeniskelamin = new JLabel();
    JLabel jabatan = new JLabel();
    JLabel notelp = new JLabel();
    JButton simpan = new JButton();
    JButton ubah  = new JButton();
    JButton hapus = new JButton();
    JButton baca = new JButton();
    JButton reset = new JButton();
    JTextArea txtidkeeper = new JTextArea();
    JTextField txtnama  = new JTextField();
    JTextArea TXTalamat = new JTextArea();
    JTextArea txtnotelp = new JTextArea();
    JTextArea TXTtampil = new JTextArea();

    public GUI(){

        idkeeper.setText("ID Keeper");
        idkeeper.setBounds(10,
                10,
                60,
                30);

        add(idkeeper);
        txtidkeeper.setBounds(110,
                10,
                300,
                30);
        add(txtidkeeper);

        nama.setText("Nama");
        nama.setBounds(10,
                50,
                60,
                30);
        add(nama);
        txtnama.setBounds(110,
                50,
                300,
                30);
        add(txtnama);

        alamat.setText("Alamat");
        alamat.setBounds(10,
                90,
                100,
                30);
        add(alamat);
        TXTalamat.setBounds(110,
                90,
                300,
                200);
        scroll = new JScrollPane(TXTalamat);
        scroll.setBounds(110,
                90,
                300,
                200);
        add(scroll);

        jeniskelamin.setText("Jenis Kelamin");
        jeniskelamin.setBounds(10,
                300,
                100,
                30);
        add(jeniskelamin);
        rd_laki = new JRadioButton("Laki-Laki");
        rd_laki.setBounds(110,
                300,
                100,
                30);
        add(rd_laki);
        rd_perempuan = new JRadioButton("Perempuan");
        rd_perempuan.setBounds(220,
                300,
                100,
                30);
        add(rd_perempuan);

        jabatan.setText("Jabatan");
        jabatan.setBounds(10,
                340,
                100,
                30);
        add(jabatan);
        String pilih[] = {"Pilihan","Kepala Keeper","Dokter Hewan","Keeper", "Staff", "Babu"};
        jc_jabatan = new JComboBox(pilih);
        jc_jabatan.setBounds(110,
                340,
                300,
                30);
        add(jc_jabatan);

        notelp.setText("Nomotr Telp");
        notelp.setBounds(10,
                380,
                100,
                30);

        add(notelp);
        txtnotelp.setBounds(110,
                380,
                300,
                30);
        add(txtnotelp);

        simpan.setText("Simpan");
        simpan.setBounds(10,
                420,
                400,
                30);
        simpan.addActionListener(this);
        add(simpan);

        baca.setText("Baca");
        baca.setBounds(10,
                460,
                400,
                30);
        baca.addActionListener(this);
        add(baca);

        ubah.setText("Ubah");
        ubah.setBounds(10,
                500,
                400,
                30);
        ubah.addActionListener(this);
        add(ubah);

        hapus.setText("Hapus");
        hapus.setBounds(10,
                540,
                400,
                30);
        hapus.addActionListener(this);
        add(hapus);

        setLayout(null);
        setTitle("Kebun Binatang");
        setSize(437,
                620);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
        setResizable(false);
    }

    public void BuatFile() throws IOException {
        String nameFile = "hasil_input.txt";
        FileOutputStream outFile = new FileOutputStream(nameFile);
        try{
            DataOutputStream outStream = new DataOutputStream(outFile);
            outStream.writeUTF("ID Keeper   : "+Idkeeper);
            outStream.writeUTF("Nama   : "+Nama);
            outStream.writeUTF("Alamat  : "+Alamat);
            outStream.writeUTF("Jenis Kelamin : "+JenisKelamin);
            outStream.writeUTF("Jabatan   : "+Jabatan);
            outStream.writeUTF("Nomor Telepon   : "+Notelp);
            outStream.close();
            JOptionPane.showMessageDialog(this, "Data Keeper Telah tersimpan");

        }
        catch (IOException e){
            System.err.println("ERROR LUR : "+e.getMessage() + "\n");
        }
    }

    public void BacaFile() throws IOException{
        String nameFile = "hasil_input.txt";
        String idkeeper;
        String nama;
        String alamat;
        String jkelamin;
        String jabatan;
        String notelp;
        String isi;

        try{
            FileInputStream inFile      = new FileInputStream(nameFile);
            DataInputStream inStream    = new DataInputStream(inFile);
            idkeeper    = inStream.readUTF();
            nama        = inStream.readUTF();
            alamat      = inStream.readUTF();
            jkelamin    = inStream.readUTF();
            jabatan     = inStream.readUTF();
            notelp      = inStream.readUTF();
            isi = idkeeper +"\n"+nama +"\n"+ alamat +"\n"+ jabatan +notelp +"\n"+"\n"+ jkelamin;
            inStream.close();
            System.out.println(isi);
        }catch (FileNotFoundException e){
            System.err.println("File "+nameFile +" 404 \n");
        }catch (IOException ex ){
            System.err.println("ERROR LUR : "+ex.getMessage() + "\n");
        }
    }

    @Override
    public void actionPerformed(ActionEvent e)  {
        if(e.getActionCommand().equals("Simpan")){
            Nama = txtnama.getText();
            Alamat = TXTalamat.getText();
            if(rd_laki.isSelected()){
                JenisKelamin = "Pria";
            }else{
                JenisKelamin = "Wanita";
            }
            Jabatan = (String) jc_jabatan.getSelectedItem();
            try {
                BuatFile();
            } catch (IOException ex) {}

        }else if(e.getActionCommand().equals("Tampil")){
            try {
                BacaFile();
            } catch (IOException ex) {}
        }else{
            dispose();
        }
    }
}