package sample;

public class HapusData {
}
