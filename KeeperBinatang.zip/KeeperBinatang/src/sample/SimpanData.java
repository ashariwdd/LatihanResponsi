package sample;

import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class SimpanData {
    Statement statement;

    void InputData(String idkeeper, String nama, String alamat, String jeniskelamin, String jabatan, String notelp){
        Koneksi koneksi = new Koneksi();
        try{
            statement = koneksi.getConnection().createStatement();
            String sql = "INSERT INTO datakebunbinatang VALUES ('"+ idkeeper + "','" + nama + "','" + alamat + "','" + jeniskelamin + "','" + jabatan + "','" + notelp + "')";
            statement.executeUpdate(sql);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(SimpanData.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
    }
}
